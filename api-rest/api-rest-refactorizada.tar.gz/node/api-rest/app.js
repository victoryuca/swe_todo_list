'use strict'

const express = require ('express')
const bodyParser = require('body-parser') //para la peticion http
const app = express()
const v1 = require('./routes')

app.use(bodyParser.urlencoded({ extended : false }))
app.use(bodyParser.json())
app.use('/v1', v1)

module.exports = app