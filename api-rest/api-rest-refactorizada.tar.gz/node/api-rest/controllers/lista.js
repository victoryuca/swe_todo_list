'use strict'

const Todo = require('../models/todo')

/*function getTodo (id){

}*/

function getTodos(req, res){
	Todo.find({}, (err, todos) => {
		if (err) return res.status(500).send({message: `Error al realizar la peticion: ${err}`})
		if (!todos) return res.status(404).send({message: `No existen tareas`})

		res.send(200, {todos})
	})
}

function saveTodo(){
	console.log('POST /v1/todos')
	console.log(req.body)

	let todo = new Todo()
	todo.nombre = req.body.nombre
	todo.descripcion = req.body.descripcion
	todo.completada = req.body.completada
	todo.fecha = req.body.fecha

	todo.save((err, todoStored) => {
		if (err) res.status(500).send({message: `Error al guardar en BD: ${err}`})

		res.status(200).send({id: todo._id})
	})
}

function updateTodo(req, res){
	let id = req.params.id
	let update = req.body

	Todo.findByIdAndUpdate(id, update, (err, todoUpdated) => {
		if (err) res.status(500).send({message: `Error al actualizar la tarea: ${err}`})

		res.status(200).send({ todos: todoUpdated })
	})

}

function deleteTodo(req, res){
	let id = req.params.id

	Todo.findById(id, (err, todo) => {
		if (err) res.status(500).send({message: `Error al borrar el tarea: ${err}`})

		todo.remove(err => {
			if (err) res.status(500).send({message: `Error al borrador la tarea: ${err}`})
			res.status(200).send({message: 'EL producto ha sido eliminado'})
		})
	})
}

module.exports = {
	getTodos,
	saveTodo,
	updateTodo,
	deleteTodo
}