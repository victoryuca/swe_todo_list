'use strict'

const express = require('express')
const listaCtrl = require('../controllers/lista')
const v1 = express.Router()

v1.get('/todos', listaCtrl.getTodos)
v1.post('/todos', listaCtrl.saveTodo)
v1.put('/todos/:id', listaCtrl.updateTodo)
v1.delete('/todos/:id', listaCtrl.deleteTodo)

module.exports = v1