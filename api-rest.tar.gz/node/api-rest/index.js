'use strict'

const express = require ('express')
const bodyParser = require('body-parser') //para la peticion http

//crear nuestro servidor

const Todo = require('./models/todo')

const app = express()
const port = process.env.PORT || 3001
const mongoose = require('mongoose')

app.use(bodyParser.urlencoded({ extended : false }))
app.use(bodyParser.json())

app.get('/v1/todos', (req, res) => {
	Todo.find({}, (err, todos) => {
		if (err) return res.status(500).send({message: `Error al realizar la peticion: ${err}`})
		if (!todos) return res.status(404).send({message: `No existen tareas`})

		res.send(200, {todos})
	})
})


/*MOSTRAR POR ID app.get('/v1/todos/:todoId' , (req, res) => {
	let todoId = req.params.todoId

	Todo.findById(todoId, (err, todo) => {
		if (err) return res.status(500).send({message:`Error al realizar la peticion ${err}`})
		if (!todo) return res.status(404).send({message: `La tarea no existe`})

		res.status(200).send({todos: todo})
	})

})*/


app.post('/v1/todos', (req, res) => {
	console.log('POST /v1/todos')
	console.log(req.body)

	let todo = new Todo()
	todo.nombre = req.body.nombre
	todo.descripcion = req.body.descripcion
	todo.completada = req.body.completada
	todo.fecha = req.body.fecha

	todo.save((err, todoStored) => {
		if (err) res.status(500).send({message: `Error al guardar en BD: ${err}`})

		res.status(200).send({id: todo._id})
	})
})


app.put('/v1/todos/:id', (req , res) => {
	let id = req.params.id
	let update = req.body

	Todo.findByIdAndUpdate(id, update, (err, todoUpdated) => {
		if (err) res.status(500).send({message: `Error al actualizar la tarea: ${err}`})

		res.status(200).send({ todos: todoUpdated })
	})
})

app.delete('/v1/todos/:id', (req , res) => {
	let id = req.params.id

	Todo.findById(id, (err, todo) => {
		if (err) res.status(500).send({message: `Error al borrar el tarea: ${err}`})

		todo.remove(err => {
			if (err) res.status(500).send({message: `Error al borrador la tarea: ${err}`})
			res.status(200).send({message: 'EL producto ha sido eliminado'})
		})
	})
})

mongoose.connect('mongodb://localhost:27017/todo', (err, res) => {
	if (err){
     return console.log(`Error al conectar a la base de datos: ${err} `)
	}
	console.log('Conexion a la base de datos establecica...')
	
	
	app.listen(port, () => {
	console.log(`API REST corriendo en http://localhost:${port}`)
   })
})
